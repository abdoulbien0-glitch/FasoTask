package bf.fasotask;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView balance, title;
    int points = 0;

    int green = Color.rgb(10,122,75);
    int dark = Color.rgb(16,22,20);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        showLogin();
    }

    TextView tv(String s, int size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(20,16,20,16);
        return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); return b;
    }

    void showLogin(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,50,28,28);
        TextView logo=tv("FasoTask 🇧🇫",32); logo.setTextColor(green);
        root.addView(logo);
        root.addView(tv("Gagne des récompenses en réalisant des sondages et missions.",18));
        EditText email=new EditText(this); email.setHint("Téléphone ou e-mail");
        root.addView(email);
        EditText pass=new EditText(this); pass.setHint("Mot de passe"); pass.setInputType(129);
        root.addView(pass);
        Button login=btn("Se connecter");
        root.addView(login);
        Button register=btn("Créer mon compte");
        root.addView(register);
        login.setOnClickListener(v->showHome());
        register.setOnClickListener(v->showHome());
        setContentView(root);
    }

    void showHome(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout top=new LinearLayout(this); top.setPadding(20,18,20,8);
        title=tv("Bonjour 👋",24); top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button profile=btn("Profil"); top.addView(profile);
        root.addView(top);

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(28,20,28,20); card.setBackgroundColor(green);
        TextView c=tv("SOLDE DISPONIBLE",14); c.setTextColor(Color.WHITE); card.addView(c);
        balance=tv("0 point",30); balance.setTextColor(Color.WHITE); card.addView(balance);
        TextView fc=tv("≈ 0 FCFA",16); fc.setTextColor(Color.WHITE); card.addView(fc);
        root.addView(card);

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,10,16,80);
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(dark);
        String[] ns={"🏠 Accueil","🎯 Missions","💰 Portefeuille","👥 Parrainage"};
        for(String n:ns){Button x=btn(n); nav.addView(x,new LinearLayout.LayoutParams(0,65,1)); if(n.contains("Missions"))x.setOnClickListener(v->missions()); if(n.contains("Portefeuille"))x.setOnClickListener(v->wallet()); if(n.contains("Parrainage"))x.setOnClickListener(v->referral());}
        root.addView(nav);
        setContentView(root);
        dashboard();
    }

    void clear(){content.removeAllViews();}

    void dashboard(){
        clear();
        content.addView(tv("Missions disponibles",22));
        addTask("Sondage Burkina Faso", "5 minutes • 500 points", 500);
        addTask("Donner ton avis sur une boutique", "3 minutes • 300 points", 300);
        addTask("Mission photo", "10 minutes • 800 points", 800);
    }

    void addTask(String name,String detail,int reward){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18,12,18,12);
        box.addView(tv(name,19)); box.addView(tv(detail,14));
        Button b=btn("Faire la mission");
        box.addView(b);
        b.setOnClickListener(v->{points+=reward; updateBalance(); Toast.makeText(this,"Mission terminée : +"+reward+" points",Toast.LENGTH_LONG).show(); b.setEnabled(false); b.setText("Terminée ✓");});
        content.addView(box);
    }

    void missions(){ dashboard(); }

    void wallet(){
        clear();
        content.addView(tv("Portefeuille",26));
        content.addView(tv("Solde : "+points+" points",20));
        content.addView(tv("Conversion indicative : 100 points = 100 FCFA",14));
        content.addView(tv("Retrait minimum : 2 000 FCFA",15));
        Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Orange Money","Wave"})); content.addView(sp);
        EditText num=new EditText(this); num.setHint("Numéro de paiement"); content.addView(num);
        Button wd=btn("Demander un retrait");
        content.addView(wd);
        wd.setOnClickListener(v->{
            if(points<2000){Toast.makeText(this,"Solde insuffisant.",Toast.LENGTH_LONG).show();return;}
            Toast.makeText(this,"Demande enregistrée. Validation admin requise.",Toast.LENGTH_LONG).show();
        });
    }

    void referral(){
        clear();
        content.addView(tv("Parrainage",26));
        content.addView(tv("Ton code : FASO"+String.format("%04d", new Random().nextInt(10000)),20));
        content.addView(tv("Invite tes amis et reçois un bonus après leur première mission validée.",16));
        Button share=btn("Partager mon code");
        content.addView(share);
        share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"Rejoins FasoTask 🇧🇫 avec mon code de parrainage !");startActivity(Intent.createChooser(i,"Partager"));});
    }

    void updateBalance(){ if(balance!=null) balance.setText(points+" points"); }
}
