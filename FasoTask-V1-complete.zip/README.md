# FasoTask V1

Application Android + API + espace admin.

Fonctions V1:
- inscription / connexion locale de démonstration
- tableau de bord
- sondages et missions
- récompenses en points
- portefeuille
- demande de retrait Orange Money / Wave
- parrainage
- historique
- API Node.js de base
- dashboard admin web de démonstration

IMPORTANT: cette V1 n'effectue pas encore de paiements réels. Les retraits sont enregistrés comme demandes et doivent être validés côté serveur/admin avant toute intégration Orange Money/Wave.
