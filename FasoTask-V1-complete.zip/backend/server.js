import express from "express";
import cors from "cors";
const app=express(); app.use(cors()); app.use(express.json());
const tasks=[
 {id:1,title:"Sondage Burkina Faso",description:"Donner ton avis",reward:500},
 {id:2,title:"Mission boutique",description:"Visiter et répondre",reward:700},
 {id:3,title:"Mission photo",description:"Prendre une photo comme preuve",reward:800}
];
const withdrawals=[];
app.get("/api/health",(req,res)=>res.json({ok:true,service:"FasoTask API"}));
app.get("/api/tasks",(req,res)=>res.json(tasks));
app.post("/api/withdrawals",(req,res)=>{const w={id:withdrawals.length+1,...req.body,status:"pending",createdAt:new Date().toISOString()};withdrawals.push(w);res.status(201).json(w)});
app.get("/api/admin/withdrawals",(req,res)=>res.json(withdrawals));
app.listen(process.env.PORT||3000,()=>console.log("FasoTask API running"));
